	<nav class="ts-sidebar">
		<ul class="ts-sidebar-menu">

			<li class="ts-label">Main</li>
			<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>

			<li><a href="#"><i class="fa fa-globe"></i> Site</a>
				<ul>
					<li><a href="create-brand.php">Our Team</a></li>
					<li><a href="our-mandate">Our Mandate</a></li>
					<li><a href="sliders">Manage Sliders</a></li>
					<li><a href="partners">Partners</a></li>
					<li><a href="statistics">Statistics</a></li>
					<li><a href="testimonials">Manage Testimonials</a></li>
				</ul>
			</li>

			<li><a href="#"><i class="fa fa-cogs"></i> Services</a>
				<ul>
					<li><a href="services">Manage Services</a></li>
				</ul>
			</li>
			<li><a href="#"><i class="fa fa-road"></i> Projects</a>
				<ul>
					<!-- <li><a href="post-avehical.php">Post a Projects</a></li> -->
					<li><a href="projects">Manage Projects</a></li>
				</ul>
			</li>
			<li><a href="#"><i class="fa fa-image"></i> Photos</a>
				<ul>
					<li><a href="new-bookings.php">Services Photos</a></li>
					<li><a href="project-gallery">Project Gallery</a></li>
					<!-- <li><a href="canceled-bookings.php">Canceled</a></li> -->
				</ul>
			</li>



			<li><a href="manage-conactusquery.php"><i class="fa fa-envelope"></i> Manage Contactus Query</a></li>
			<!-- <li><a href="reg-users.php"><i class="fa fa-sliders"></i>Manage Sliders</a></li> -->
			<!-- <li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li> -->
			<li><a href="settings"><i class="fa fa-cog"></i> Settings</a></li>

			<li><a href="manage-subscribers.php"><i class="fa fa-table"></i> Manage Subscribers</a></li>

		</ul>
	</nav>