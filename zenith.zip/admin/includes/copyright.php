<style>
  
    .text.center {
      width: 100%;
      margin: 25px auto;
      text-align: center;
    }
  @media (min-width: 600px) {
    .text.center {
      width: 100%;
      /* margin: auto 35% !important; */
      text-align: center;
    }
  }
 
</style>
<div class="text center">
  &copy;
  <script>
    document.write(new Date().getFullYear());
  </script>
  Zenith Construction Limited
</div>

