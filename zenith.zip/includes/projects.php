<?php
include_once 'functions.php';
global $dbh;
$projects = fetchAllProjects($dbh);
?>
