    <div id="top-bar">
            <div id="top-bar-inner" class="container">
              <div class="top-bar-inner-wrap">
                <div class="top-bar-content">
                  <div class="inner">
                    <span class="address content"
                      ><?php echo $rows['Address'] ?></span
                    >
                    <span class="phone content"><?php echo $rows['ContactNo'] ?></span>
                    <span><i class="fa fa-envelope m-auto"></i> <?php echo $rows['EmailId'] ?></span>
                  </div>
                </div>
                <!-- /.top-bar-content -->

                <div class="top-bar-socials">
                  <div class="inner">
                    <span class="text">Follow us:</span>
                    <span class="icons">
                      <a href="#"><i class="fa fa-facebook"></i></a>
                      <a href="#"><i class="fa fa-twitter"></i></a>
                      <a href="#"><i class="fa fa-instagram"></i></a>
                    </span>
                  </div>
                </div>
                <!-- /.top-bar-socials -->
              </div>
            </div>
          </div>